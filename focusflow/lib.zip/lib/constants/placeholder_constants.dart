// Placeholder for app constants
