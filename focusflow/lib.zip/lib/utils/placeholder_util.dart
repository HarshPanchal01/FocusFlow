// Placeholder for utility functions
